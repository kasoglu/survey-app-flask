import json
from sqlalchemy import create_engine, Column, Integer, String, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

# Veritabanı bağlantısı ve modelin oluşturulması
Base = declarative_base()


# Soru tablosu modeli
class Question(Base):
    __tablename__ = 'questions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_id = Column(Integer, unique=True)
    question_text = Column(String, nullable=False)
    definition = Column(Text, nullable=False)

    # Sorunun seçenekleriyle ilişkilendirilmesi
    options = relationship("Option", back_populates="question")


# Seçenek tablosu modeli
class Option(Base):
    __tablename__ = 'options'

    id = Column(Integer, primary_key=True, autoincrement=True)
    text = Column(Text, nullable=False)
    score = Column(Integer, nullable=False)
    question_id = Column(Integer, ForeignKey('questions.id'), nullable=False)

    question = relationship("Question", back_populates="options")


# Veritabanını oluştur
engine = create_engine('sqlite:///database.db')
Base.metadata.create_all(engine)

# Oturum oluşturma
Session = sessionmaker(bind=engine)
session = Session()

# JSON verilerini yükle
with open('questions.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# JSON verilerini SQLAlchemy modellerine ekleme
for question_data in data['questions']:
    question = Question(
        question_id=question_data['question_id'],
        question_text=question_data['question'],
        definition=question_data['definition']
    )

    # Seçenekleri ekle
    for option_data in question_data['options']:
        option = Option(
            text=option_data['text'],
            score=option_data['score'],
            question=question
        )
        session.add(option)

    session.add(question)

# Veritabanına kaydet
session.commit()

print("Sorular ve seçenekler başarıyla veritabanına kaydedildi.")
