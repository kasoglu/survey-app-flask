from flask import Flask, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import RadioField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'your_secret_key'

db = SQLAlchemy(app)

# Veritabanı Modelleri
class Question(db.Model):
    __tablename__ = 'questions'
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, unique=True)
    question = db.Column(db.String, nullable=False)
    definition = db.Column(db.Text, nullable=False)
    options = db.relationship('Option', backref='question', lazy=True)

class Option(db.Model):
    __tablename__ = 'options'
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    score = db.Column(db.Integer, nullable=False)  # Seçenek için puan
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'), nullable=False)

class Answer(db.Model):
    __tablename__ = 'answers'
    id = db.Column(db.Integer, primary_key=True)
    question_text = db.Column(db.String, nullable=False)  # Sorunun metni
    selected_option_text = db.Column(db.String, nullable=False)  # Seçilen cevabın metni
    total_score = db.Column(db.Integer, nullable=False)  # Toplam puan


# Dinamik Form Oluşturma
class SurveyForm(FlaskForm):
    options = RadioField('Seçenekler', choices=[], validators=[DataRequired()])
    submit = SubmitField('Next')


# Dinamik Radyo Butonları ekleme fonksiyonu
# def create_question_form(question):
#     class QuestionForm(FlaskForm):
#         options = RadioField(question.question, choices=[(str(opt.id), opt.text) for opt in question.options],
#                              validators=[DataRequired()])
#         submit = SubmitField('Next')
#
#     return QuestionForm


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/anket/soru/<int:soru_id>', methods=['GET', 'POST'])
def survey(soru_id):
    question = Question.query.filter_by(question_id=soru_id).first()

    if not question:
        return redirect(url_for('results'))

    form = SurveyForm()
    form.options.choices = [(str(opt.id), opt.text) for opt in question.options]  # Seçenekleri ayarla

    if form.validate_on_submit():

        selected_answer_id = form.options.data  # Seçilen seçeneğin ID'si
        selected_option = Option.query.get(selected_answer_id)

        # Cevap kaydetme
        answer = Answer(
            question_text=question.question,  # Sorunun metni
            selected_option_text=selected_option.text,  # Seçilen cevabın metni
            total_score=selected_option.score  # Seçilen seçeneğin puanı
        )

        try:
            db.session.add(answer)  # Cevabı veritabanına ekle
            db.session.commit()  # Değişiklikleri kaydet
        except Exception as e:
            db.session.rollback()  # Hata durumunda geri al
            print(f"Veritabanı hatası: {e}")  # Hata mesajını yazdır

        next_question_id = soru_id + 1

        # Son soru kontrolü
        if not Question.query.filter_by(question_id=next_question_id).first():
            return redirect(url_for('results'))

        return redirect(url_for('survey', soru_id=next_question_id))


    return render_template('survey.html', form=form, question=question)




@app.route('/anket/sonuc')
def results():
    answers = Answer.query.all()
    total_score = sum(answer.total_score for answer in answers)  # Toplam puanı hesapla
    return render_template('results.html', answers=answers, total_score=total_score)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
